#!/bin/bash

g++ main.cpp mgmres.c
./a.out 
python3 plot.py 
