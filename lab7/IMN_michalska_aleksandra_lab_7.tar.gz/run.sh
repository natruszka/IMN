g++ -O3 main.cpp
./a.out
python3 plot.py